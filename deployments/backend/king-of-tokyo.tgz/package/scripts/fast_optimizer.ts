// Fast Optimizer Draft
