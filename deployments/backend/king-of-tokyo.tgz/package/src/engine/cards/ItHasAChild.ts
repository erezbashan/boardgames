import { KotState, PendingAction } from '../types';
import { CardImplementation } from './types';
import { addLog } from '../utils';

export const ItHasAChild: CardImplementation = {
  id: 'it_has_a_child',
  name: 'It Has a Child',
  cost: 7,
  type: 'Keep',
  description: 'If you are eliminated discard all your cards and markers, and lose all your ⭐ and ⚡. Heal to 10❤️ and start again.',
  verified: true,
  onPreEvent: (st: KotState, action: PendingAction, pId: string) => {
    if (action.type === 'DEAD' && action.playerId === pId) {
      addLog(st, action, `${st.players[pId].name} used It Has a Child! They are reborn!`);
      
      // Heal to 10
      st.players[pId].health = st.settings.maxHealth;
      
      // Lose all stars and energy
      st.players[pId].vp = 0;
      st.players[pId].energy = 0;
      
      // Discard all cards
      st.players[pId].cards = [];
      st.players[pId].cardState = {};
      
      // Clear markers
      st.players[pId].markers = {};
      
      // Cancel the DEAD action
      st.pendingActions.shift();
    }
    return st;
  }
};
